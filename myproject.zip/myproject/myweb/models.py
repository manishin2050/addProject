from django.db import models
# Create your models here.
class Data(models.Model):
    proj_id = models.AutoField(primary_key=True)
    proj_name = models.CharField(max_length=30,null=False)
    proj_desc=models.TextField(null=True)
    folder_loc = models.CharField(max_length=500,null=False)
    file_loc= models.CharField(max_length=500,null=False)
    proj_img= models.ImageField(null=True, upload_to='static/images/',default='static/default/images.jpeg')
    date=models.DateField(null=True)



    def __str__(self):
        return self.proj_name +(f' ({self.proj_id})')


# add file and folder name to this database