from django.shortcuts import render,HttpResponse,redirect
from myweb.models import Data
from datetime import datetime
from django.contrib import messages
import os,webbrowser

# Create your views here.

def index(request):
    # print(Data.name)
    data={
        'data':Data.objects.all().values()
    }
    if request.method=="POST":
        proj_name= request.POST.get('proj_name')
        folder_loc= request.POST.get('folder_loc')
        file_loc= request.POST.get('file_loc')
        proj_desc= request.POST.get('desc')
        # proj_img= request.POST.get('proj_img')
        proj_img= request.FILES.get('proj_img')
        date=datetime.now()
        if proj_img == None:
            datas= Data(proj_name=proj_name,folder_loc=folder_loc,file_loc=file_loc,proj_desc=proj_desc,date=date)
        else:
            datas= Data(proj_name=proj_name,folder_loc=folder_loc,file_loc=file_loc,proj_desc=proj_desc,proj_img=proj_img,date=date)
        datas.save()
        messages.success(request,'Data has Saved',datas)
    return render(request,"index.html",data)
    # return HttpResponse("welcome my love :")

def run(request,proj_id):
    data=Data.objects.get(proj_id =proj_id).file_loc
    file= rf'{data}'
    file = file.replace('\\','\\\\')
    os.startfile(file)
    # print(file)
    return redirect('/')

def open(request,proj_id):
    data= Data.objects.get(proj_id=proj_id).folder_loc
    file= rf'{data}'
    file = file.replace('\\','\\\\')
    webbrowser.open(file)
    # print(file)
    return redirect('/')



def about(request,proj_id):
    data={
        'name':Data.objects.get(proj_id=proj_id).proj_name,
        'img':Data.objects.get(proj_id=proj_id).proj_img,
        'desc':Data.objects.get(proj_id=proj_id).proj_desc,
    }
    return render(request,'about.html',data)
def edit(request,proj_id):

    data={
        'name':Data.objects.get(proj_id=proj_id).proj_name,
        'id':Data.objects.get(proj_id=proj_id).proj_id,
        'folder':Data.objects.get(proj_id=proj_id).folder_loc,
        'file':Data.objects.get(proj_id=proj_id).file_loc,
        'img':Data.objects.get(proj_id=proj_id).proj_img,
        'date':Data.objects.get(proj_id=proj_id).date,
        'desc':Data.objects.get(proj_id=proj_id).proj_desc,
    }
    if request.method=="POST":
        proj_name= request.POST.get('proj_name')
        folder_loc= request.POST.get('folder_loc')
        file_loc= request.POST.get('file_loc')
        proj_desc= request.POST.get('proj_desc')
        proj_img= request.FILES.get('proj_img')
        date=datetime.now()
        img=Data.objects.get(proj_id=proj_id).proj_img # this is for delete pehli image
        if proj_img==None:
            proj_img=Data.objects.get(proj_id=proj_id).proj_img # this is for delete pehli image
            datas= Data(proj_id=proj_id,proj_name=proj_name,folder_loc=folder_loc,file_loc=file_loc,proj_desc=proj_desc,proj_img=proj_img,date=date)
        else:
            if img=='static/default/images.jpeg':
                # proj_img=Data.objects.get(proj_id=proj_id).proj_img # this is for delete pehli image
                datas= Data(proj_id=proj_id,proj_name=proj_name,folder_loc=folder_loc,file_loc=file_loc,proj_desc=proj_desc,proj_img=proj_img,date=date)

            else:
                img.delete()
                # proj_img=Data.objects.get(proj_id=proj_id).proj_img # this is for delete pehli image
                datas= Data(proj_id=proj_id,proj_name=proj_name,folder_loc=folder_loc,file_loc=file_loc,proj_desc=proj_desc,proj_img=proj_img,date=date)
        datas.save()
        messages.success(request,'Data has Updated',datas)
        return redirect('/')
    return render(request,'update.html',data)


def delete(request,proj_id):
    img=Data.objects.get(proj_id=proj_id).proj_img # this is for delete pehli image
    if img=='static/default/images.jpeg':
        pass
    else:
        img.delete()
    data=Data.objects.filter(proj_id=proj_id).delete()
    # print(data)
    return redirect('/')
    # return HttpResponse("welcome my darling about page :")
def contact(requst):
    return HttpResponse("welcome my jaan contact page :")