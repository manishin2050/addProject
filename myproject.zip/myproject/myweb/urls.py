from django.urls import path
from myweb import views

urlpatterns = [
    path('', views.index, name="index" ),
    path('run/<int:proj_id>', views.run, name="run" ),
    path('open/<int:proj_id>', views.open, name="open" ),
    path('about/<int:proj_id>', views.about, name="about" ),
    path('edit/<int:proj_id>', views.edit, name="edit" ),
    path('delete/<int:proj_id>', views.delete, name="delete" ),
    path('contact', views.contact, name="contact" )

]
