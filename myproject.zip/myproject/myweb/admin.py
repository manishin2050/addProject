from django.contrib import admin
from myweb.models import Data

# Register your models here.
admin.site.register(Data)