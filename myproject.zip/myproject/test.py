import os,webbrowser
# from datetime import datetime
os.remove('static/12.png')
print()

# os.startfile("D:\\edting mix code\\bubbles website\\index.html")
# webbrowser.open('D:\\danvici projects\\youtube  your ADVISOR FRIENDchat gpt videos\\02_07_23-Your Advisor Friend')